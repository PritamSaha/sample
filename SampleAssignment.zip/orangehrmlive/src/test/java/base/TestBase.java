package base;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import utilities.ExcelReader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class TestBase {

public static WebDriver driver; // declaring webdiriver 

public static  Properties config = new Properties();
public static  Properties OR = new Properties();
public static FileInputStream fis;
public static Logger log = Logger.getLogger("devpinoylogger");
public static ExcelReader excel =new ExcelReader("/home/pritam/eclipse-workspace/orangehrmlive/src/test/resources/excel/testdata.xlsx");

@BeforeSuite
public void setUp() throws IOException
{
if(driver==null)
{
	fis = new FileInputStream(System.getProperty("user.dir")+"/src/test/resources/propeties/Config.properties");
	config.load(fis); 
	fis = new FileInputStream(System.getProperty("user.dir")+"/src/test/resources/propeties/OR.properties");
	OR.load(fis);
} 

if(config.getProperty("browser").equalsIgnoreCase("chrome"))
{
System.out.println("Chrome");	
System.setProperty("webdriver.chrome.driver", "/home/pritam/Downloads/chromedriver/chromedriver_linux64/chromedriver");
driver= new ChromeDriver();
log.debug("Chrome Launched.");

}

driver.get(config.getProperty("testsiteurl"));
log.debug("Navigated to Test URL.");
driver.manage().window().maximize();
driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")), TimeUnit.SECONDS);
}

public boolean isEelementPresent(By by)
{
try {
	driver.findElement(by);
	return true;
}catch(NoSuchElementException e)
{
return false;	
}

}



@AfterSuite
public void tearDown()
{
if(driver!=null)
{
	driver.quit();	
	log.debug("Test execution completed");
}
}
}




