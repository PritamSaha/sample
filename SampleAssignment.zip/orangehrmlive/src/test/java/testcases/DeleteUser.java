package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.TestBase;

public class DeleteUser extends TestBase{
	@Test
	public void payment() throws InterruptedException
	
	{
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("Admin"))).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("SearchUser"))).sendKeys("PritamSahaN");
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("Search"))).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath(OR.getProperty("Select"))).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("Delete"))).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("Ok"))).click();
		Thread.sleep(1000);
	}

}
