package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import base.TestBase;

public class UpdateUser extends TestBase{
	@Test
	public void updateUser() throws InterruptedException
	
	{	Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("Admin"))).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("SearchUser"))).sendKeys("PritamSahaN");
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("Search"))).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath(OR.getProperty("User"))).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath(OR.getProperty("Edit"))).click();
		Thread.sleep(4000);
		Select date = new Select(driver.findElement(By.xpath(OR.getProperty("Status"))));
		date.selectByValue("0");
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("SaveUpdate"))).click();
		Thread.sleep(1000);
		
	}

}
